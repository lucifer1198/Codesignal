/**
 * Section 1
 * This Section deals with the basci UI part of Plugin
 */
/**************************************************************************************************************************************/
var workitemsPerPage = 25; //Number of workitems to be shown in a single table page load.
selectedWorkItems = new Map(); //Contains a map with Workitem id as Key and Workitem comment as value.
//Contains selected workitems for bulk action by user.

var res; //Gets data from Custom Object created to load elements on page.
var pg2; //Total number of pages in pagination table.

var html1 //HTML code to be put for creation of button on Workitems.jsf page
var id1; //Gets the id of native element on workitems.jsf page to put Bulk Action Button after it using jQuery.
var id2; //Gets the id of native element on workitems.jsf page to put Bulk Action Overlay Table before it using jQuery.
var id3; //Gets the id of native element on workitems.jsf page to check if all elements on the page has been loaded.
var homePageUrl;
var workitemsPageUrl;
var n = 0;
var pageURL;
var foregroundProvisioning;

/**
 * REST function call to get data[id1, id2, id3 and html1] from custom Object
 */
function getVersion()
{
	//console.log(document.readyState);
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/test/customObject", true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.send();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			// console.log(this.readyState);
			// console.log(this.status);
			res = JSON.parse(this.responseText);
			id1 = res.id1;
			id2 = res.id2;
			id3 = res.id3;
			html1 = res.html1;
			foregroundProvisioning = res.foregroundProvisioning;
			homePageUrl = res.homePageUrl;
			workitemsPageUrl = res.workitemsPageUrl;
			//  console.log(res);
			// console.log(res == null)
			if(res != null)
			{
				pageUrl = window.location.pathname;
				if (pageUrl.toString() ==  SailPoint.CONTEXT_PATH+homePageUrl)
				{
					// console.log("Home Page");
					loadHomePageData();
				}
				jQuery("body").one('DOMSubtreeModified', id3 , function() 
				{
					//console.log(document.readyState);
					loadPageData();
				});
			}
		}	
	}
}

if(document.readyState === "interactive")
{
	getVersion();
}


function loadHomePageData()
{
    jQuery("body").on('DOMSubtreeModified', '.sp-body', function() {
        if(jQuery('.text-ellipsis.ng-binding:first-child').length>0)
        {
            if(jQuery('#button1').length==0)
            {
                //Creation of Bulk Action Button
                jQuery("span[title='Latest Approvals']").after('<div id="button1" class="x-btn x-box-item x-toolbar-item x-btn-default-toolbar-medium x-noicon x-btn-noicon x-btn-default-toolbar-medium-noicon" style="border-width: 1px; left: 300px; top: 6px; margin: 0px;"> 	 	<em id="button2"> 	 		<button id="Overly" type="button"  class="x-btn-center overly" hidefocus="true" role="button" style="height: 24px;"> 	 			<span id="button4" class="x-btn-inner" style="">Bulk Action</span> 	 			<span id="button5" class="x-btn-icon "></span> 	 		</button> 	 	</em> 	 </div>');
            
                    //Creation of Bulk Action Table Overlay
                    jQuery('body').append(
                '<div id="ogrooModel" class="modalbox ogroobox">'+
                    '<div class="dialog">'+'<div class="container">'+'<button id = "close" role="button" aria-live="polite" type="button" class="btn btn-sm btn-white ng-binding" ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()">X</button>'+'</div>'+
					 	'<div class="panel-heading tooltip-wrapper container-fluid" style="border: 1px solid #ddd;background-color:#011e69;color:#ffffff;padding-top: 0px; padding-bottom: 4px; align:left">'+
						 	'<h4><center>Bulk Request</center></h4>'+
                            '</div>'+
                            //Error or Warning text
                            '<div style="visibility:hidden" id="error-text"></div>'+

                            //CSS Loader
                            '<div id="loader"></div>'+

                            //Pagination Button Group
                            '<div id="btn-grp" style="border:1px solid #D5D8DC; padding: 5px;visibility:hidden"></div>'+
                            
                            '<div style="padding: 8px;">'+
						/*Cancel Button for table overlay
							'<button  style="float:left" id="close" tabindex="50" role="button" aria-live="polite" type="button" class="btn btn-sm btn-white ng-binding"  ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()">Cancel</button>'+*/
							'<span class="btn-group-xs-only">'+

                                //Reject Button for table overlay
                                '<button style="visibility:hidden;float: right;" id="reject" onclick="reject()" aria-pressed="false" class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false">'+
                                    '<i class="fa fa-thumbs-down text-danger"  role="presentation"></i>&nbsp;Deny All'+
                                '</button></span><span class="btn-group-xs-only" style="padding: 15px;height: 10px;bottom: 100px;left: 100px;">'+
                                //Approve Button for table overlay
                                '<button id="approve" onclick="approve()" aria-pressed="false"  class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" style="visibility:hidden;float:right;margin-right:16px">'+
                                    '<i class="fa fa-thumbs-up text-success" role="presentation"></i>&nbsp;Approve All'+
                                        '</button></span>'+
                                        //Common Comments Check Box
                                    '<label class="checkbox-inline" id="com-cmnt" style="visibility:hidden">&nbsp;'+
                                        '<input type="checkbox" id="com-cmnt-checkbox" onclick="openCommonCommentBox()" value=""><b>Common Comments</b>'+
                                    '</label>'+
                            '</div>'+
                            '<br/>'+
                            '<div class="cmnt-modal form-group" id="cmnt-box">'+
                                '<div class="dialog-box">'+
                                    '<label for="comment">Comment:</label>'+
                                    '<input type="text" class="form-control" id="comment" oninput="addCommonComment(this.id)" /><br/>'+
                                    '<div>'+'<button class="btn btn-default" onclick="dismissCommonComment()">Cancel</button>'+
                                    '<button class="btn btn-default" onclick="approve()" style="float: right;">Approve All</button>'+
                                    '<button class="btn btn-default" id="rejAll" onclick="reject()" style="float: right;margin-right:10px">Reject All</button>'+
                                        
                                    '</div>'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                        //Hidden Span Used to store totalPages value for pagination table
                    '</div><span id="pgSpan" style="visibility:hidden"></span>');
                    
                    //Success text
                    jQuery('div.panel-heading.tooltip-wrapper.container-fluid').after('<div style="visibility:hidden" id="success-text">'+
                                                    '</div>');

                    if(jQuery('#button1').length!=0)
				{
				document.getElementById("Overly").addEventListener("click", function(){
			         	var e =document.getElementsByClassName("modalbox");
			e[0].style.display = 'block';
			jQuery('#loader').after('<table id="item_table" style="visibility:hidden">'+
						 	'<thead>'+
							 	'<tr style="text-align: center;">'+
								 	'<th style="text-align: center;width:2%;">'+
										'<input type="checkbox" id ="All" class="all" onchange="checkState(this.id, this.value)"/><b>&nbsp; '+
									'</th>'+
									
									'<th style="text-align: center; width:6%">ID</th>'+
									'<th style="text-align: center; width:5%">Requestee</th>'+
									'<th style="text-align: center; width:14%">Requester</th>'+
									'<th style="text-align: center; width:10%">Requested For</th>'+
									'<th style="text-align: center; width:4%">Application</th>'+
									'<th style="text-align: center; width:2%">Requested On</th>'+
									'<th style="text-align: center; width:12%">Comments</th>'+
								'</tr>'+
							'</thead></table>');
			
			getData(workitemsPerPage,1);
			
			var tableData = document.getElementById('table1');
			
		});
		
		// Get the modal
			var modal =document.getElementById('ogrooModel');
			
		// When the user clicks anywhere outside of the modal, close it
			window.onclick = function(event) {
				if (event.target === modal) {
					modal.style.display = "none";
					jQuery('#item_table').empty();
				}
			}
			
			
		document.getElementById("close").addEventListener("click", function(){
			document.getElementById("item_table").style.visibility = "hidden";
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display= 'none';
			var cmntBox = document.getElementsByClassName('cmnt');
			// console.log(jQuery('input#All.all'));
			jQuery('input#All.all')[0].checked = false;
			for(var i = 0; i < cmntBox.length; i++)
			{
				cmntBox[i].value = "";
			}

			jQuery('#item_table').empty();
			
			jQuery('#cmnt-box').css("visibility", "hidden");
			jQuery('#btn-grp').css("visibility", "hidden");
			jQuery('#approve').css("visibility", "hidden");
			jQuery('#reject').css("visibility", "hidden");
			jQuery('#com-cmnt').css("visibility", "hidden");
			jQuery('.check').each(function (){
				this.checked = false;
			});
			selectedWorkItems.clear();
		});
	
		}
                }  
            }
    });
}

function loadPageData()
{
		jQuery(id1).after(html1);//Creation of Bulk Action Button

			//Creation of Bulk Action Table Overlay
			jQuery(id2).before('<div class="modalbox">'+
				'<div class="dialog">'+'<div class="container">'+'<button id = "close" role="button" aria-live="polite" type="button" class="btn btn-sm btn-white ng-binding" ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()">X</button>'+'</div>'+
					 	'<div class="panel-heading tooltip-wrapper container-fluid" style="border: 1px solid #ddd;background-color:#011e69;color:#ffffff;padding-top: 0px; padding-bottom: 4px; align:left">'+
						 	'<h4><center>Bulk Request</center></h4>'+
							'</div>'+
							
							//Error or Warning text
							'<div style="visibility:hidden" id="error-text"></div>'+
							
							//CSS Loader
							'<div id="loader"></div>'+

							//Pagination Button Group
						'<div id="btn-grp" style="border:1px solid #D5D8DC; padding: 5px;visibility:hidden"></div>'+
						
						
						'<div style="padding: 8px;">'+
						/*Cancel Button for table overlay
							'<button  style="float:left" id="close" tabindex="50" role="button" aria-live="polite" type="button" class="btn btn-sm btn-white ng-binding"  ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()">Cancel</button>'+*/
							'<span class="btn-group-xs-only">'+
							
							//Reject Button for table overlay
							'<button style="visibility:hidden;float: right;" id="reject" onclick="reject()" aria-pressed="false" class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false">'+
								'<i class="fa fa-thumbs-down text-danger"  role="presentation"></i>&nbsp;Deny All'+
							'</button></span><span class="btn-group-xs-only" style="padding: 15px;height: 10px;bottom: 100px;left: 100px;">'+
							
							//Approve Button for table overlay
							'<button id="approve" onclick="approve()" aria-pressed="false"  class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" style="visibility:hidden;float:right;margin-right:16px">'+
								'<i class="fa fa-thumbs-up text-success" role="presentation"></i>&nbsp;Approve All'+
									'</button></span>'+
									//Common Comments Check Box 
								'<label class="checkbox-inline" id="com-cmnt" style="visibility:hidden">&nbsp;'+
									'<input type="checkbox" id="com-cmnt-checkbox" onclick="openCommonCommentBox()" value=""><b>Common Comments</b>'+
								'</label>'+
						'</div>'+
						'<br/>'+
						
						//Common Comment Overlay
						'<div class="cmnt-modal form-group" id="cmnt-box">'+
							'<div class="dialog-box">'+
								'<label for="comment">Comment:</label>'+
								'<input type="text" class="form-control" id="comment" oninput="addCommonComment(this.id)" /><br/>'+
								'<div>'+'<button class="btn btn-default" onclick="dismissCommonComment()">Cancel</button>'+
								'<button class="btn btn-default" onclick="approve()" style="float: right;">Approve All</button>'+
                                '<button class="btn btn-default" id="rejAll" onclick="reject()" style="float: right;margin-right:10px">Reject All</button>'+
									
								'</div>'+
							'</div>'+
						'</div>'+
					'</div>'+
					
					//Hidden Span Used to store totalPages value for pagination table
				'</div><span id="pgSpan" style="visibility:hidden"></span>')
				
				//Success text
				jQuery('div.panel-heading.tooltip-wrapper.container-fluid').after('<div style="visibility:hidden" id="success-text">'+
												'</div>');
                document.getElementById("Overly").addEventListener("click", function(){
			
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display = 'block';

			//Creating table header and structure here.
			jQuery('#loader').after(
				'<table id="item_table" style="visibility:hidden;">'+
							'<thead >'+
								'<tr>'+
									'<th style="width:2%;text-align:center;">'+
										'<input type="checkbox" id ="All" class="all" onclick="checkState(this.id, this.value)"/><b>&nbsp; '+
									'</th>'+
									
									'<th style="width:6%;text-align:center;">ID</th>'+
									'<th style="width:5%;text-align:center;">Requestee</th>'+
									'<th style="width:14%;text-align:center;">Requester</th>'+
									'<th style="width:14%;text-align:center;">Requested For</th>'+
									'<th style="width:4%;text-align:center;">Application</th>'+
									'<th style="width:2%;text-align:center;">Requested On</th>'+
									'<th style="width:12%;text-align:center;">Comments</th>'+
								'</tr>'+
							'</thead></table>');
			//REST call to get workitems for present showing page on Overlay Table.
			getData(workitemsPerPage,1);
		});
		
		//jQuery for Closing Overlay onclick of Cancel(id="close") Button

		document.getElementById("close").addEventListener("click", function(){
			document.getElementById("item_table").style.visibility = "hidden";
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display= 'none';
			jQuery('.check').each(function (){
				this.checked = false;
			});
			// console.log(jQuery('input#All.all'));
			jQuery('input#All.all')[0].checked = false;
			jQuery('#item_table').empty();
			
			jQuery('#cmnt-box').css("visibility", "hidden");
			jQuery('#btn-grp').css("visibility", "hidden");
			jQuery('#approve').css("visibility", "hidden");
			jQuery('#reject').css("visibility", "hidden");
			jQuery('#com-cmnt').css("visibility", "hidden");

			selectedWorkItems.clear();
			workitemsPerPage = 25;
		});
}
/**************************************************************************************************************************************/
/**
 * Section 2 
 * This Section deals with all service(REST) calls like getting a workitem and approving or rejecting it.
 */
/**************************************************************************************************************************************/
function getData(pageSize,pageCount)
{
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/test/items", true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.setRequestHeader('pageSize', pageSize);
	xhttp.setRequestHeader('pageCount', pageCount);
	xhttp.send();
	xhttp.onreadystatechange = function() {
		// console.log("Inside getdata()");
		if (this.readyState == 4 && this.status == 200) {
			objString = this.responseText.toString();
			//console.log(this.responseText);
			
			if(objString.charAt(0) == '<' )
			{
				//console.log("Some Error Occurred!!");
				
				jQuery('#error-text').css("visibility","visible");
				jQuery('#error-text').addClass("formError"); 
				jQuery('#error-text')[0].innerHTML = "Some Error Occured!! Contact System Admin";
			}
			
			else
			{
				obj = JSON.parse(this.responseText);
				if(obj.length <= 0 )
				{
						jQuery('#error-text').css("visibility","visible");
						jQuery('#error-text').removeClass('formError');
						jQuery('#error-text').addClass("formWarn"); 
						jQuery('#error-text')[0].innerHTML = "No Records to Display for Bulk Operation";
						jQuery('#loader').css("display", "none");

						jQuery('#item_table').css("visibility", "hidden");
						jQuery('#btn-grp').css("visibility", "hidden");
						jQuery('#approve').css("visibility", "hidden");
						jQuery('#reject').css("visibility", "hidden");
						jQuery('#com-cmnt').css("visibility", "hidden");
						jQuery('#bottom-display')[0].innerHTML = 'No Data to Display'
				}

				else if (obj === 'undefined')
				{	
					jQuery('#error-text').css("visibility","visible");
					jQuery('#error-text').removeClass('formError');
					jQuery('#error-text').addClass("formWarn");
					jQuery('#error-text')[0].innerHTML = "Data format not Supported!!"
					jQuery('#loader').css("display", "none")

					jQuery('#item_table').css("visibility", "hidden");
					jQuery('#btn-grp').css("visibility", "hidden");
					jQuery('#approve').css("visibility", "hidden");
					jQuery('#reject').css("visibility", "hidden");
					jQuery('#com-cmnt').css("visibility", "hidden");
				}

				else
				{
					console.log(obj);
					totalWorkitems = obj[0].totalItems;
					//console.log(totalWorkitems);
					jQuery('#error-text').css("visibility","hidden");
					jQuery('#error-text')[0].innerHTML = "";
					jQuery('#loader').css("display", "block")
					pg = obj[0].NoOfPages;
					document.getElementById("pgSpan").innerHTML = pg;
					var pg1=document.getElementById("pgSpan").innerHTML;
					// console.log("No. Of Pages = "+pg1);
					pg2 = pg1;
					// console.log("###"+pg2);
					var btnGrp = document.getElementById('btn-grp');
					html = '<td colspan="8">'
					html += '<button id="backward" onclick="doPaginationActions(`backward`)" class="btn btn-default"><i class="fa fa-step-backward"></i></button>&nbsp;&nbsp;';
					html += '<button id="left" onclick="doPaginationActions(`left`)" class="btn btn-default"><i class="fa fa-arrow-left"></i></button>&nbsp;&nbsp;';
					html += '<span>Page &nbsp;&nbsp;<input id="pageCount" autocomplete="off" onkeyup="changePageOnText(event)" value="1" type="text" style="height: 30px; width: 30px;padding:5px;"/></span> of <span id="numPages">'+obj[0].NoOfPages+'&nbsp;&nbsp;</span>';
					html += '<button id="right" onclick="doPaginationActions(`right`)" class="btn btn-default"><i class="fa fa-arrow-right"></i></button>&nbsp;&nbsp;';
					html += '<button id="forward" onclick="doPaginationActions(`forward`)" class="btn btn-default"><i class="fa fa-step-forward"></i></button>&nbsp;&nbsp;';
					html += '<button id="refresh" onclick="doPaginationActions(`refresh`)" class="btn btn-default"><i class="fa fa-refresh"></i></button>&nbsp;&nbsp;';
					html += 'Show &nbsp;&nbsp;<select onchange="getWorkitemValues(this)" class="numOfwi" id="selectItems"><option>5</option><option>10</option><option>20</option><option>25</option><option>50</option><option>100</option></select>&nbsp;&nbsp; items';
					html += '<span id="bottom-display" class="float-xs-right" style="float:right;padding-top:10px;">No Data to Display</span>';
					html += '</td>'
					btnGrp.innerHTML = html
					while(true)
					{
						if(pg1 > 0)
						{
							loadData();
							document.getElementById("pageCount").value = pageCount;
							jQuery('#selectItems')[0].value = workitemsPerPage;
							jQuery("#numPages").innerHTML = pg2;
							break;
						}
					}
				}
			}
			
		}		
	}
	////console.log(window.pg1);
}

function approve()
{
	jQuery('#loader').css("display", "block");
	jQuery('#approve').attr("disabled", "disabled");
	jQuery('#reject').attr("disabled", "disabled");
		var result={};
	//console.log(selectedWorkItems);
	if(selectedWorkItems.size > 0)
	{
		var keys = selectedWorkItems.keys();
		var val = selectedWorkItems.values();
		for (var i = 0; i < selectedWorkItems.size; i++)
		{
			result[keys.next().value] = val.next().value;
		}

		if(JSON.parse(foregroundProvisioning) == true)
		{
			console.log(result);
		var xhttp = new XMLHttpRequest();
		xhttp.open("POST", "/identityiq/plugin/rest/test/approval", true);
		xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
		xhttp.setRequestHeader('Content-Type', 'application/json');
		//xhttp.send(JSON.stringify({ "id": "0000000219", "response": { "name": "Tester" } }));
		xhttp.send(JSON.stringify(result));
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				resultObject = this.responseText;
				var currentPage = document.getElementById('pageCount').value;
				window.location.reload();
				}
			}
		}
		else
		{
			var xhttp = new XMLHttpRequest();
		xhttp.open("POST", "/identityiq/plugin/rest/test/approval", true);
		xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
		xhttp.setRequestHeader('Content-Type', 'application/json');
		//xhttp.send(JSON.stringify({ "id": "0000000219", "response": { "name": "Tester" } }));
		xhttp.send(JSON.stringify(result));
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				resultObject = this.responseText;
				var currentPage = document.getElementById('pageCount').value;
				alert("Your Task is running in background");
				window.location.reload();
				}
			}
			
		}
		
		// }
	}
	else
	{
		jQuery('#error-text').css('visibility', 'visible');
		jQuery('#error-text').addClass("formWarn"); 
		jQuery('#error-text')[0].innerHTML = "Please select at least One check box";
	}
}

function reject()
{
    jQuery('#loader').css("display", "block");
	jQuery('#approve').attr("disabled", "disabled");
	jQuery('#reject').attr("disabled", "disabled");
	var result={};
	//console.log(selectedWorkItems);
	if(selectedWorkItems.size > 0)
	{
		var keys = selectedWorkItems.keys();
		var val = selectedWorkItems.values();
		for (var i=0;i<selectedWorkItems.size;i++)
		{
			result[keys.next().value] = val.next().value;
		}
		//console.log(result);
		var xhttp = new XMLHttpRequest();
		xhttp.open("POST", "/identityiq/plugin/rest/test/reject", true);
		xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
		xhttp.setRequestHeader('Content-Type', 'application/json');
		xhttp.send(JSON.stringify(result));
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				resultObject = this.responseText;
				var currentPage = document.getElementById('pageCount').value;
				//console.log(currentPage)
				/*console.log("Hello");
				jQuery(".post").remove();
				jQuery('#success-text').css('visibility', 'visible');
				jQuery('#success-text').addClass("formInfo");
				jQuery('#success-text')[0].innerHTML = "Your Request has been successfully submitted.";
				dismiss();
				selectedWorkItems.clear();
				getData(workitemsPerPage,currentPage);*/
				window.location.reload();
			}
		}
	}
	else
	{
		jQuery('#error-text').css('visibility', 'visible');
		jQuery('#error-text').addClass("formWarn"); 
		jQuery('#error-text')[0].innerHTML = "Please select at least One check box";
	}
}
/**************************************************************************************************************************************/
/**
 * Section 3
 * This Section deals with all the UI table manipulation.
 */
/**************************************************************************************************************************************/
function loadData()
{
	// console.log("Inside loaddata()")
	if(jQuery('#pgSpan').innerHTML != '')
	{
		// console.log("Calling Show Table")
		myVar = setTimeout(showTable, 1500);
		jQuery('#error-text').css('visibility', 'hidden');
		jQuery('#error-text').removeClass("formWarn"); 
		jQuery('#error-text')[0].innerHTML = "";
	}
}

function showTable() {
	// console.log("Inside showtable()")
	disableEnableButtons();
	document.getElementById("loader").style.display = "none";
	jQuery('#All')[0].checked = false;
	jQuery('#item_table').css("visibility","visible");
	jQuery('#reject').css("visibility","visible");
	jQuery('#approve').css("visibility","visible"); 
	jQuery('#com-cmnt').css("visibility", "visible")
	jQuery('#btn-grp').css("visibility", "visible")

	var html = '<tbody id="table1" style="background-color:##E5E8E8">';
	for (var i=0; i<obj.length; i++) {
		if(obj[i].Critical.toString() == "true")
		{
			html += '<tr class="post" title="'+obj[i].Description+'">';
		//console.log(obj[i].Description);
			html += '<td style="width:3%;"><input class="check" type="checkbox" id="check'+obj[i].Name+'" value="'+obj[i].Name+'" onclick="checkState(this.id, this.value)"/></td>';
			html +=	'<td style="width:3%;color:red"><span><i class="fa fa-exclamation-triangle" style="color:red;font-size:13px">&nbsp;&nbsp;'+ obj[i].Name +'</i></span></td>';
			html +=	'<td style="width:9%;">' + obj[i].Requestee + '</td>';
			html += '<td style="width:8%;">' + obj[i].Requester + '</td>';
			html +=	'<td style="width:12%;color:red">' + obj[i].Operation + '</td>';
			//console.log(obj[i].Operation);
			html += '<td style="width:9%;color:red">' + obj[i].Application + '</td>';
			html += '<td style="width:9%;">' + obj[i].Created + '</td>';
			html += '<td style="width:10%;"><input disabled="disabled" type="text" class="cmnt" oninput="changeCmntValue(this.id)" id="cmnt'+obj[i].Name+'"/></td>';						
			html += "</tr>";
		}
		else
		{
			// console.log(obj[i]);
			html += '<tr class="post" title="'+obj[i].Description+'">';
			//console.log(obj[i].Description);
			html += '<td style="width:3%;" ><input class="check" type="checkbox" id="check'+obj[i].Name+'" value="'+obj[i].Name+'" onclick="checkState(this.id, this.value)"/></td>';
			html +=	'<td style="width:3%;">'+ obj[i].Name +'</td>';
			html +=	'<td style="width:9%;">' + obj[i].Requestee + '</td>';
			html += '<td style="width:8%;">' + obj[i].Requester + '</td>';
			html +=	'<td style="width:20%;">' + obj[i].Operation + '</td>';
			//console.log(obj[i].Operation);
			html += '<td style="width:9%;">' + obj[i].Application + '</td>';
			html += '<td style="width:9%;">' + obj[i].Created + '</td>';
			html += '<td style="width:10%;"><input disabled="disabled" type="text" class="cmnt" oninput="changeCmntValue(this.id)" id="cmnt'+obj[i].Name+'"/></td>';						
			html += "</tr>";
		}
	}
	html += '</tbody>';
	jQuery(html).appendTo('#item_table');
	jQuery('#bottom-display')[0].innerHTML = 'Displaying '+obj[0].No+' - '+obj[obj.length-1].No+' of '+totalWorkitems;

	 for (var i=0; i<obj.length; i++) {
	 	if(selectedWorkItems.has(obj[i].Name))
	 	{
	 		var obj_id = '#check'+obj[i].Name;
	 		jQuery(obj_id)[0].checked = true;
	 		jQuery('#cmnt'+obj[i].Name).removeAttr('disabled');
	 	}
	}

	jQuery('#backward').attr("disabled", "disabled");
	jQuery('#left').attr("disabled", "disabled");

	var totalPages=document.getElementById('pgSpan').innerHTML;
	// console.log(totalPages);
	var currentPage = document.getElementById('pageCount').value;
	// console.log(currentPage)

	if(currentPage == totalPages)
	{
		// console.log("Not Possible value")
		if(currentPage == 1)
		{
			jQuery('#forward').attr("disabled", "disabled");
			jQuery('#right').attr("disabled", "disabled");
			jQuery('#backward').attr("disabled", "disabled");
			jQuery('#left').attr("disabled", "disabled");
		}
		else
		{
			jQuery('#forward').attr("disabled", "disabled");
			jQuery('#right').attr("disabled", "disabled");
			jQuery('#backward').removeAttr("disabled");
			jQuery('#left').removeAttr("disabled");
		}
	}

	else
	{
		// console.log("Possible value")
		if(currentPage != 1)
		{
			jQuery('#backward').removeAttr("disabled");
			jQuery('#left').removeAttr("disabled");
			jQuery('#forward').removeAttr("disabled");
			jQuery('#right').removeAttr("disabled");
		}
		else
		{
			jQuery('#backward').attr("disabled", "disabled");
			jQuery('#left').attr("disabled", "disabled");
			jQuery('#forward').removeAttr("disabled");
			jQuery('#right').removeAttr("disabled");
		}
	}
}
/**************************************************************************************************************************************/
/** 
 * Section 4
 * This Section deals with Common comment functionality for Plugin
*/
/**************************************************************************************************************************************/
function dismissCommonComment()
{
	var el = document.getElementsByClassName("cmnt-modal");
	el[0].style.display = 'none';
	
	jQuery('#com-cmnt-checkbox')[0].checked = false;
	var comment = document.getElementById('comment');
	comment.value = "";
	var keys = selectedWorkItems.keys();
	// console.log(keys);
	
	selectedWorkItems.forEach(function(){
		jQuery('#cmnt'+keys.next().value).removeAttr('disabled');                            
	})             
	var cboxes = document.getElementsByClassName('check');
	
	if (jQuery('.cmnt')[0].checked == true) 
	{
		if (selectedWorkItems.size > 0)
		{
			jQuery(this).attr("readonly", "readonly");
			var vals = selectedWorkItems.values();
			// console.log(val);
			/*var res={};
			res[keys.next().value] = vals.next().value;
			console.log(res);*/
			document.getElementById(this.id).value = vals.next().value;
		}
	};
	//uncheckAll(cboxes);
	jQuery('#All')[0].checked = false;
}

function addCommonComment(objId)
{
	var comment = document.getElementById(objId);
	var keys = selectedWorkItems.keys();
	
	//if(selectedWorkItems.length > 0)
	//{
					//console.log("abc");
	selectedWorkItems.forEach(function(){
					selectedWorkItems.set(keys.next().value, comment.value);
	})
	//}
}


function openCommonCommentBox()
{
	var el = document.getElementsByClassName("cmnt-modal");
	el[0].style.display = 'block';
	
	var chckBox = document.getElementById('com-cmnt-checkbox');

	if(chckBox.checked)
	{
					//console.log(selectedWorkItems);
		if(selectedWorkItems.size <= 0)
		{
			jQuery('#error-text').css('visibility', 'visible');
			jQuery('#error-text').addClass("formWarn"); 
			jQuery('#error-text')[0].innerHTML = "Please select at least One check box";
			jQuery('#cmnt-box').hide();
			chckBox.checked = false;
		}
		else
		{
			jQuery('#cmnt-box').css("visibility", "visible");
			jQuery('#error-text').css('visibility', 'hidden');
			jQuery('#error-text').removeClass("formWarn"); 
			jQuery('#error-text')[0].innerHTML = "";
			jQuery('.cmnt').each(function() {
            jQuery(this).attr("readonly", "readonly");
			})
		}
	}

	else
	{
		jQuery('#cmnt-box').css("visibility", "hidden");
		
		jQuery('.cmnt').each(function() {
						jQuery(this).removeAttr('readonly');                       
		})

		var keys = selectedWorkItems.keys();
		selectedWorkItems.forEach(function(){
						selectedWorkItems.set(keys.next().value, "");
		})
		var cmntBox = document.getElementById('comment');
		cmntBox.value = "";			
	}                
}
/**************************************************************************************************************************************/
/** 
 * Section 5
 * This Section contains all the Utility functions for Plugin to work properly.
*/
/**************************************************************************************************************************************/
function changeCmntValue(id)
{
	var cmntBox = document.getElementById(id);
	var cmnt = cmntBox.value;
	var idVal = id.substring(4);
	selectedWorkItems.set(idVal,cmnt);
}

function checkState(id, value)
{
    var idVal = id.substring(5);
	// console.log(id+' '+value);
	// console.log(jQuery('#cmnt'+value)[0].value);
	if(id == 'All')
	{
		if(jQuery('#'+id)[0].checked == true)
		{
			jQuery('.check').each(function (){
				this.checked = true;
				selectedWorkItems.set(this.id.substring(5), jQuery('#cmnt'+this.value)[0].value);
				jQuery('#cmnt'+this.value).removeAttr("disabled");
			});
			disableEnableButtons();
		}

		if(jQuery('#'+id)[0].checked == false)
		{
			jQuery('.check').each(function (){
				this.checked = false;
				jQuery('#cmnt'+this.value).attr("disabled", "disabled");
			});
			selectedWorkItems.clear();
			disableEnableButtons();
		}
	}

	else
	{
		
		if(jQuery('#'+id)[0].checked == true)
		{
			// console.log("single check");
			selectedWorkItems.set(idVal, jQuery('#cmnt'+value)[0].value);
			jQuery('#cmnt'+value).removeAttr("disabled");
            var temp = checkIfAllChecked();
            if(temp == true)
            	jQuery('#All')[0].checked = true;  
			disableEnableButtons();
		}
		else
		{
			//console.log(selectedWorkItems.delete(id));
			// console.log(jQuery('#All')[0].checked)
			if(jQuery('#All')[0].checked == true)
				jQuery('#All')[0].checked = false;
			
			jQuery('#cmnt'+value).attr("disabled", "disabled");
			selectedWorkItems.delete(idVal);
			disableEnableButtons();
		}
	}
	console.log(selectedWorkItems);
}

function changePageOnText(event)
{
	// console.log("Inside func")
	if (event.keyCode === 13) 
	{
		// console.log("Inside condn")
		event.preventDefault();
		var pageCount1 = jQuery("#pageCount").val();
		valueValid = false;
		var presentPage = parseInt(pageCount1)
		var totalPages = parseInt(pg2);
			if(Number.isInteger(presentPage) && presentPage > 0)
			{
				// console.log("valid Value")
				valueValid = true;
			}
			else
			{
				// console.log("Invalid Value")
				valueValid = false;
			}
		// console.log("Page : "+presentPage+"  Total : "+pg2)
		// console.log(presentPage <= totalPages)
		// console.log(valueValid)
		if(valueValid && presentPage <= totalPages)
		{
			// console.log("Calling getdata");
			jQuery(".post").remove();
			jQuery("#table1").remove();
			getData(workitemsPerPage,pageCount1);
		}
	}
}				
	
function doPaginationActions(event)
{
	var pageCount1 = jQuery("#pageCount").val();
	switch (event) {
	case 'left':
		// console.log('go left');
		if(parseInt(pageCount1) > 1)
		{
			pageCount1--;
		}
		jQuery("#table1").remove();
		// console.log("Left : "+workitemsPerPage)
		// console.log("Left : "+pageCount1)
		getData(workitemsPerPage,parseInt(pageCount1));
		break;

	case 'right':
		// console.log('go right');
		if(parseInt(pageCount1) < parseInt(pg2))
		{
			pageCount1++; 
		}
		jQuery("#table1").remove();
		// console.log("Right : "+workitemsPerPage)
		// console.log("Right : "+pageCount1)
		getData(workitemsPerPage,parseInt(pageCount1));
		break;

	case 'forward':
		// console.log('go forward');
		document.getElementById("pageCount").value = pg2;
		jQuery("#table1").remove();
		getData(workitemsPerPage,parseInt(pg2));
		break;

    case 'backward':
		//console.log('go backward');
		document.getElementById("pageCount").value = 1;
		jQuery("#table1").remove();
		getData(workitemsPerPage,1);
		break;
	
	case 'refresh':
		//console.log('do refresh');
		var pageCount1=jQuery("#pageCount").val();
		jQuery("#table1").remove();
		getData(workitemsPerPage,parseInt(pageCount1));
        checkSelectedItems();
        break;
	}
}
//Workitems number change function through selectedWorkItems

function getWorkitemValues(numVal)
{
	// console.log(numVal.value);
	var pageCount1=jQuery("#pageCount").val();
	jQuery("#table1").remove();
	// console.log(pageCount1);
	if(pageCount1 != 1)
	{
		pageCount1 = 1;
	}
	getData(numVal.value,pageCount1);
	workitemsPerPage = numVal.value
	jQuery('#selectItems')[0].value = numVal.value;
}

function checkIfAllChecked()
{
    jQuery('.check').each(function (){
        if(this.checked == true)
            isAllChecked = true;
        
        if(this.checked == false)
        {    
            isAllChecked = false;
             return isAllChecked;
        }
    });
    return isAllChecked;
}

function disableEnableButtons()
{
    if(selectedWorkItems.size > 0)
    {
		jQuery('#loader').removeAttr("disabled");
        jQuery('#approve').removeAttr("disabled");
        jQuery('#reject').removeAttr("disabled");
    }
	else
	{
        jQuery('#loader').attr("disabled","disabled");
        jQuery('#approve').attr("disabled","disabled");
        jQuery('#reject').attr("disabled","disabled");
	}
}

function checkSelectedItems()
{
    console.log("hello");
    console.log(selectedWorkItems.size);
    for(var i = 0; i < selectedWorkItems.size; i++)
    {
        console.log(selectedWorkItems[i]);
    }
}